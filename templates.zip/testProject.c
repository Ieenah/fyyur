#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct Taxi
{
int id ; 
char driver[20] ; 
char category[20] ; // “standard”, “Business” or “Family”
char plate[7];
char color[20] ; 
float rate ; 
float minCharge ; 
char state ; 

struct Taxi *next ; 

};
//----------------------
struct Taxi *list = NULL ; 

void addTripCar(){
struct Taxi *head  = NULL , *current ; 
FILE* fp;

fp = fopen("Taxies.txt", "r");
if( fp == NULL)
return ; 

char *firstLine;
fgets( firstLine, 100,  fp)  ; // read first line in file and ignor it
int i ; 
for(  i = 0 ; i < 6 ; i++){
struct Taxi  *temp = (struct Taxi *) malloc(sizeof(struct Taxi));
fscanf(fp, "%d %s  %s %s %s %f %f ", &(temp->id) , temp->driver , temp->category , temp->plate , temp->color , &(temp->rate) , &(temp->minCharge) );
temp->state = 'A' ; 
temp->next = NULL; 
if( head == NULL)
{
//head = (struct Taxi *) malloc(sizeof(struct Taxi));
head = temp ;
current = head ; 
}
else
{
current->next = temp ; 
current = current->next ; 
}

}// end for 

list = head ; 
fclose(fp);
}
//----------------------
void setTripCar(char *category , float *rate)
{
if( list == NULL)
{
printf("empty list\n"); 
return ; 
}

struct Taxi *current  ; 
current = list ; 

while( current != NULL){
 if( strcmp( current->category , category )  == 0  &&  current->rate == *rate)
  {
  current->state = 'R' ; 
  return ; 
  }                      
 current = current->next ; 
  }
 

}
//-----------------------
void writeCarsInRide (char* fileName){
if( list == NULL){
printf("empty list\n"); 
return ; 
}

FILE  *fpo;
fpo = fopen(fileName, "a"); // Open a file to append
if (fpo == NULL){
printf("Error opening file\n"); // There was an error in opening either file
return;
}

struct Taxi *current  ; 
current = list ; 

fprintf(fpo ,"--------------------------------------------------------------------------------------------\n");
fprintf(fpo ,"the cars in Ride:\n");
fprintf(fpo , "%-15s %-15s %-20s %-20s %-15s %-20s \n" , "id","driver","category",	"plate","rate" , "state");

while( current != NULL){
fprintf(fpo , "%-15d %-15s %-20s %-20s %-15.1f  %c \n", (current->id) , current->driver , current->category , current->plate , 
                        (current->rate) ,  current->state );
                        
 current = current->next ; 
 }
fclose(fpo);
}
//-----------------------

void printList()
{
if( list == NULL)
{
printf("empty list\n"); 
return ; 
}

struct Taxi *current  ; 
current = list ; 
printf( "%-20s %-20s %-20s %-20s %-20s %-20s %-20s %-20s\n" , "id","driver","category",	"plate","color","rate" ,"mincharge" , "state");

while( current != NULL){
printf( "%-20d %-20s %-20s %-20s %-20s %-20.1f %-20.2f %c \n", (current->id) , current->driver , current->category , current->plate , 
                        current->color , (current->rate) , (current->minCharge) , current->state );
                               
 current = current->next ; 
 }
}


int main()
{

addTripCar(); 
printf("The Available Cars.\n");
printList();
char *s1 = "Business" ; float f1 = 4.5 ; 
char *s2= "Family" ; float f2 = 5.5 ; 
char *s3= "Family" ; float f3 = 4.0 ;
char *s4= "standard" ; float f4 = 3.4 ; 
char *s5= "standard" ; float f5 = 5.0 ;

setTripCar( s1 , &f1 ); 
setTripCar( s2 , &f2 ); 
setTripCar( s3 , &f3 ); 
setTripCar( s4 , &f4 ); 
setTripCar( s5 , &f5 ); 

printf("\n----------------------------------------------------\n");
printf("the Cars in Ride :\n"); 
printList();

char *fileName = "Taxies.txt" ; 
writeCarsInRide(fileName); 


return 0; 
}